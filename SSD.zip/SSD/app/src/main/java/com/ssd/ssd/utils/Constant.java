package com.ssd.ssd.utils;

public class Constant {
    public String url = "http://202.111.28.161/";
}
