package com.ssd.ssd;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Test;

public class InsertFoodActivityTest {

    @After
    public void tearDown() throws Exception {
    }

    @Test
    public void attachBaseContext() {
    }

    @Test
    public void setTheme() {
    }
}