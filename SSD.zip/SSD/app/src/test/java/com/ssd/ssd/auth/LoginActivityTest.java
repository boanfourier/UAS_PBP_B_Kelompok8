package com.ssd.ssd.auth;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

public class LoginActivityTest {

    @Test
    public void onCreate() {

    }

    @Test
    public void onStart(){

    }

}