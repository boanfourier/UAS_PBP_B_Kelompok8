package com.ssd.ssd.model;

import static org.junit.Assert.*;

import org.junit.Test;

public class ResponseTest {

    @Test
    public void getMessage() {
    }

    @Test
    public void getData() {
    }
}