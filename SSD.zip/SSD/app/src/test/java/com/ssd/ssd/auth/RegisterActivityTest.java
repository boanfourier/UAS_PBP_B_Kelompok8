package com.ssd.ssd.auth;

import static org.junit.Assert.*;

import org.junit.Test;

public class RegisterActivityTest {

    @Test
    public void attachBaseContext() {
    }

    @Test
    public void setTheme() {
    }
}